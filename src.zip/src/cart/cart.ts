import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
selector:'app-cart',
standalone:true,
templateUrl:'./cart.html'
})
export class CartComponent{

constructor(private router:Router){}

checkout(){
this.router.navigate(['/checkout']);
}

}