import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
selector:'app-address',
standalone:true,
templateUrl:'./address.html'
})
export class AddressComponent{

constructor(private router:Router){}

payment(){
this.router.navigate(['/payment']);
}

}