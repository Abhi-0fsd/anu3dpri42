import { Routes } from '@angular/router';
import { Home } from './home/home';
import { ProductDetailsComponent } from './product-details/product-details';
import { CartComponent } from './cart/cart';
import { CheckoutComponent } from './checkout/checkout';
import { AddressComponent } from './address/address';
import { PaymentComponent } from './payment/payment';
import { OrderSuccessComponent } from './ordersuccess/ordersuccess';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'product/:id', component: ProductDetailsComponent },
  { path: 'cart', component: CartComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'address', component: AddressComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'success', component: OrderSuccessComponent }
];