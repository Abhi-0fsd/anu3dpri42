import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector:'app-product-details',
  standalone:true,
  templateUrl:'./product-details.html'
})
export class ProductDetailsComponent{

  constructor(private router:Router){}

  addToCart(){
    this.router.navigate(['/cart']);
  }

}