import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
selector:'app-checkout',
standalone:true,
templateUrl:'./checkout.html'
})
export class CheckoutComponent{

constructor(private router:Router){}

address(){
this.router.navigate(['/address']);
}

}