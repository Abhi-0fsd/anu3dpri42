import { Component } from '@angular/core';

@Component({
  selector: 'app-product',
  standalone: true,
  template: `
    <h1>3D Printing Products</h1>
    <p>Welcome to Products Page</p>
  `
})
export class PaymentComponent {}